import com.sap.gateway.ip.core.customdev.util.Message
 
def Message processData(Message message) {
    def body = message.getBody(java.io.InputStream)
    def bytes = body.bytes  // safe for CPI
    // Convert or process manually
    message.setBody(bytes)
    return message
}