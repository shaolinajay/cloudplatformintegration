username = flow.getVariable("request.header.username")
password = flow.getVariable("request.header.password")
if(username =="Ajay" and password=="Ajay@123"):
    flow.setVariable("crctcred","yes")
else:
    flow.setVariable("crctcred","no")