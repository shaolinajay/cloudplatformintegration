import base64
USERNAME = "shaolinajay333@gmail.com"
PASSWORD = "Ajay@123"
credentials = (USERNAME + ":" + PASSWORD).encode("utf-8")
base64_encoded = base64.b64encode(credentials).decode("utf-8")
auth = "Basic " + base64_encoded
flow.setVariable("request.header.Authorization",auth)