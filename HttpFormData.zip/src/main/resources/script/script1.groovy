import com.sap.gateway.ip.core.customdev.util.Message
import javax.mail.internet.MimeMultipart
import javax.mail.util.ByteArrayDataSource
import javax.mail.BodyPart

def Message processData(Message message) {

    // Get raw multipart payload
    def bodyBytes = message.getBody(byte[].class)

    // Get Content-Type header (contains boundary)
    def contentType = message.getHeaders().get("Content-Type")

    // Create DataSource with correct content type
    def dataSource = new ByteArrayDataSource(bodyBytes, contentType)

    // Parse multipart message
    MimeMultipart multipart = new MimeMultipart(dataSource)

   message.setProperty("multipart",multipart)
   message.setProperty("count",multipart.getCount())

    return message
}
