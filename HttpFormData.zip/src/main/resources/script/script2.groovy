/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message
import javax.mail.internet.MimeMultipart
import javax.mail.util.ByteArrayDataSource
import java.io.ByteArrayOutputStream
def Message processData(Message message) {

    /*To set or modify the body, you can use the following methods.
    def body = message.getBody();
    message.setBody(body + " Body is modified");

    //To set or modify the headers, you can use the following methods.
    def headers = message.getHeaders();
    def value = headers.get("oldHeader");
    message.setHeader("oldHeader", value + " modified");
    message.setHeader("newHeader", "newHeader");

    //To set or modify the properties, you can use the following methods.
    def properties = message.getProperties();
    value = properties.get("oldProperty");
    message.setProperty("oldProperty", value + " modified");
    message.setProperty("newProperty", "newProperty"); */
    def properties = message.getProperties();
    multipart = properties.get("multipart");
    
    
     for (int i = 0; i < multipart.getCount(); i++) {
        def part = multipart.getBodyPart(i)

        // Check if it's a file upload
       

            def xml = part.getInputStream().getText("UTF-8")

            // Set extracted XML as body
            message.setBody(xml)
            multipart.removeBodyPart(i)
            message.setProperty("count",multipart.getCount())
            message.setProperty("multipart",multipart)
            // Optional: store as property
            message.setProperty("UploadedFileName", part.getFileName())
            break
        
    }

    return message;
}