<xsl:stylesheet version="3.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 
  <xsl:output method="xml" indent="yes"/>

    <!-- Create a new root element -->
    <xsl:template match="/*">
        <Mappings>
            <xsl:apply-templates select="//*[local-name()='entry']"/>
        </Mappings>
    </xsl:template>

    <!-- Match each entry and create a clean XML structure -->
    <xsl:template match="*[local-name()='entry']">
        <Entry>
         <Id><xsl:value-of select=".//*[local-name()='Id']"/></Id>
        <SrcValue><xsl:value-of select=".//*[local-name()='SrcValue']"/></SrcValue>
        <TgtValue><xsl:value-of select=".//*[local-name()='TgtValue']"/></TgtValue>
        </Entry>
    </xsl:template>
</xsl:stylesheet>