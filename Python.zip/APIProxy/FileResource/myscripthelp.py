apiKey = flow.getVariable("request.header.apikey")
email = flow.getVariable("email")

payload = '<root><apiKey>' + str(apiKey) + '</apiKey>' + str(email) + '</root>'
flow.setVariable("my.content", payload)