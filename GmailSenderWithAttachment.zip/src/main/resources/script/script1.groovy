import com.sap.gateway.ip.core.customdev.util.Message
import javax.activation.DataHandler

def Message processData(Message message) {

    // copy attachments
    Map<String, DataHandler> attachments =
            new HashMap<>(message.getAttachments())

    if (!attachments.isEmpty()) {

        // store copy in property
        message.setProperty("Attachments", attachments)
        message.setProperty("Size", attachments.size())

        // ✅ THIS is the ONLY supported way to clear attachments
        message.setAttachments([:])
    }

    return message
}
